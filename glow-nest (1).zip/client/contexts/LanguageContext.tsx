import { createContext, useContext, useState, ReactNode } from "react";

export type Language = "ar" | "fr";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  ar: {
    // Navigation
    "nav.home": "الرئيسية",
    "nav.courses": "الدورات",
    "nav.plans": "الخطط",
    "nav.teachers": "المدرسين",
    "nav.about": "من نحن",
    "nav.contact": "اتصل بنا",
    "nav.login": "تسجيل الدخول",
    "nav.register": "التسجيل",

    // Hero Section
    "hero.title": "أكاديمية نجاح",
    "hero.subtitle": "منصة التعليم ا��إلكتروني للثانوية العامة",
    "hero.description":
      "اكتشف طريقة جديدة للتعلم مع أفضل المدرسين والمناهج التفاعلية المصممة خصيصاً لطلاب الثانوية العامة",
    "hero.cta.primary": "ابدأ التعلم الآن",
    "hero.cta.secondary": "تصفح الدورات",

    // Features
    "features.title": "لماذا أكاديمية نجاح؟",
    "features.interactive": "تعلم تفاعلي",
    "features.interactive.desc": "دروس تفاعلية مع أحدث التقنيات التعليمية",
    "features.expert": "مدرسون خبراء",
    "features.expert.desc": "نخبة من أفضل المدرسين المتخصصين",
    "features.support": "دعم مستمر",
    "features.support.desc": "متابعة مستمرة ودعم فني على مدار الساعة",

    // Plans
    "plans.title": "اختر الخطة المناسبة لك",
    "plans.basic": "الخطة الأساسية",
    "plans.premium": "الخطة المتميزة",
    "plans.pro": "الخطة الاحترافية",
    "plans.month": "شهرياً",
    "plans.choose": "اختر الخطة",
    "plans.popular": "الأكثر شهرة",

    // Teachers
    "teachers.title": "تعرف على مدرسينا",
    "teachers.subtitle": "نخبة من أفضل المدرسين في المنطقة",
    "teachers.experience": "سنوات خبرة",
    "teachers.students": "طالب",
    "teachers.rating": "تقييم",

    // Reviews
    "reviews.title": "ماذا يقول طلابنا",
    "reviews.subtitle": "آراء حقيقية من طلاب نجحوا معنا",

    // About
    "about.title": "من نحن",
    "about.subtitle": "رسالتنا هي تحقيق النجاح الأكاديمي لكل طالب",
    "about.description":
      "أكاديمية نجاح هي منصة تعليمية رائدة تهدف إلى تمكين طلاب الثانوية العامة من تحقيق أفضل النتائج الأكاديمية من خلال توفير محتوى تعليمي عالي الجودة ومدرسين متخصصين.",

    // Contact
    "contact.title": "تواصل معنا",
    "contact.subtitle": "نحن هنا لمساعدتك في رحلتك التعليمية",
    "contact.name": "الاسم",
    "contact.email": "البريد الإلكتروني",
    "contact.message": "الرسالة",
    "contact.send": "إرسال الرسالة",

    // Tips
    "tips.title": "نصائح للنجاح",
    "tips.subtitle": "استراتيجيات مثبتة لتحقيق التفوق الأكاديمي",

    // Stats
    "stats.students": "طالب",
    "stats.courses": "دورة",
    "stats.teachers": "مدرس",
    "stats.success": "معدل النجاح",
  },
  fr: {
    // Navigation
    "nav.home": "Accueil",
    "nav.courses": "Cours",
    "nav.plans": "Plans",
    "nav.teachers": "Enseignants",
    "nav.about": "À propos",
    "nav.contact": "Contact",
    "nav.login": "Connexion",
    "nav.register": "Inscription",

    // Hero Section
    "hero.title": "Najah Academy",
    "hero.subtitle": "Plateforme d'apprentissage en ligne pour le lycée",
    "hero.description":
      "Découvrez une nouvelle façon d'apprendre avec les meilleurs enseignants et des programmes interactifs conçus spécialement pour les élèves du lycée",
    "hero.cta.primary": "Commencer à apprendre",
    "hero.cta.secondary": "Parcourir les cours",

    // Features
    "features.title": "Pourquoi Najah Academy ?",
    "features.interactive": "Apprentissage interactif",
    "features.interactive.desc":
      "Cours interactifs avec les dernières technologies éducatives",
    "features.expert": "Enseignants experts",
    "features.expert.desc": "Une élite des meilleurs enseignants spécialisés",
    "features.support": "Support continu",
    "features.support.desc": "Suivi continu et support technique 24h/24",

    // Plans
    "plans.title": "Choisissez le plan qui vous convient",
    "plans.basic": "Plan de base",
    "plans.premium": "Plan premium",
    "plans.pro": "Plan professionnel",
    "plans.month": "par mois",
    "plans.choose": "Choisir le plan",
    "plans.popular": "Le plus populaire",

    // Teachers
    "teachers.title": "Rencontrez nos enseignants",
    "teachers.subtitle": "Une élite des meilleurs enseignants de la région",
    "teachers.experience": "années d'expérience",
    "teachers.students": "étudiants",
    "teachers.rating": "évaluation",

    // Reviews
    "reviews.title": "Ce que disent nos étudiants",
    "reviews.subtitle":
      "Avis authentiques d'étudiants qui ont réussi avec nous",

    // About
    "about.title": "À propos de nous",
    "about.subtitle":
      "Notre mission est d'assurer le succès académique de chaque étudiant",
    "about.description":
      "Najah Academy est une plateforme éducative de premier plan qui vise à permettre aux élèves du lycée d'atteindre les meilleurs résultats académiques en fournissant un contenu éducatif de haute qualité et des enseignants spécialisés.",

    // Contact
    "contact.title": "Contactez-nous",
    "contact.subtitle":
      "Nous sommes là pour vous aider dans votre parcours éducatif",
    "contact.name": "Nom",
    "contact.email": "Email",
    "contact.message": "Message",
    "contact.send": "Envoyer le message",

    // Tips
    "tips.title": "Conseils pour réussir",
    "tips.subtitle": "Stratégies éprouvées pour exceller académiquement",

    // Stats
    "stats.students": "étudiants",
    "stats.courses": "cours",
    "stats.teachers": "enseignants",
    "stats.success": "taux de réussite",
  },
};

const LanguageContext = createContext<LanguageContextType | undefined>(
  undefined,
);

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [language, setLanguage] = useState<Language>("ar");

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      <div
        dir={language === "ar" ? "rtl" : "ltr"}
        className={language === "ar" ? "font-arabic" : "font-latin"}
      >
        {children}
      </div>
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
};
