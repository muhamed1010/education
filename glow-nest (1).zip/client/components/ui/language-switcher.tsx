import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "./button";
import { Globe } from "lucide-react";

export const LanguageSwitcher = () => {
  const { language, setLanguage } = useLanguage();

  return (
    <div className="flex items-center gap-2">
      <Globe className="h-4 w-4 text-muted-foreground" />
      <div className="flex rounded-lg border border-border p-1">
        <Button
          variant={language === "ar" ? "default" : "ghost"}
          size="sm"
          onClick={() => setLanguage("ar")}
          className={`text-xs px-3 ${
            language === "ar"
              ? "bg-primary text-primary-foreground"
              : "hover:bg-muted"
          }`}
        >
          العربية
        </Button>
        <Button
          variant={language === "fr" ? "default" : "ghost"}
          size="sm"
          onClick={() => setLanguage("fr")}
          className={`text-xs px-3 ${
            language === "fr"
              ? "bg-primary text-primary-foreground"
              : "hover:bg-muted"
          }`}
        >
          Français
        </Button>
      </div>
    </div>
  );
};
