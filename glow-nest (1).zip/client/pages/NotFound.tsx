import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { Home, ArrowRight, ArrowLeft } from "lucide-react";

const NotFound = () => {
  const location = useLocation();
  const { t, language } = useLanguage();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname,
    );
  }, [location.pathname]);

  const isArabic = language === "ar";

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-50 via-white to-primary-100">
      <div className="text-center space-y-8 max-w-md mx-auto px-4">
        <div className="space-y-4">
          <div className="text-8xl font-bold text-primary-600">404</div>
          <h1 className="text-2xl md:text-3xl font-bold text-foreground">
            {isArabic ? "الصفحة غير موجودة" : "Page non trouvée"}
          </h1>
          <p className="text-lg text-muted-foreground">
            {isArabic
              ? "عذراً، الصفحة التي تبحث عنها غير موجودة."
              : "Désolé, la page que vous recherchez n'existe pas."}
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild className="bg-primary-600 hover:bg-primary-700">
            <a href="/" className="flex items-center gap-2">
              <Home className="h-4 w-4" />
              {isArabic ? "العودة للرئيسية" : "Retour à l'accueil"}
              {isArabic ? (
                <ArrowLeft className="h-4 w-4" />
              ) : (
                <ArrowRight className="h-4 w-4" />
              )}
            </a>
          </Button>
        </div>

        <div className="pt-8">
          <div className="w-24 h-24 bg-yellow-100 rounded-full flex items-center justify-center mx-auto">
            <span className="text-4xl">🎓</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
