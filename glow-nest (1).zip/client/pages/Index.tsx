import { useLanguage } from "@/contexts/LanguageContext";
import { LanguageSwitcher } from "@/components/ui/language-switcher";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  BookOpen,
  Users,
  Award,
  PlayCircle,
  CheckCircle,
  Star,
  GraduationCap,
  Clock,
  Target,
  Menu,
  X,
  Phone,
  Mail,
  MapPin,
  TrendingUp,
  Brain,
  Lightbulb,
  Calendar,
  MessageCircle,
  Zap,
  Globe,
  Shield,
  HeartHandshake,
} from "lucide-react";
import { useState } from "react";

const Header = () => {
  const { t, language } = useLanguage();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const isArabic = language === "ar";

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b border-border">
      <div className="container mx-auto px-3 sm:px-4 lg:px-6">
        <div
          className={`flex items-center justify-between h-14 sm:h-16 ${isArabic ? "" : ""}`}
        >
          {/* Logo - Left side for Arabic, Right side for French */}
          <div
            className={`flex items-center gap-3 ${isArabic ? "order-1" : "order-1"}`}
          >
            <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-br from-primary-500 to-primary-700 rounded-xl flex items-center justify-center">
              <GraduationCap className="h-4 w-4 sm:h-6 sm:w-6 text-white" />
            </div>
            <div className={`flex flex-col ${isArabic ? "logo-text" : ""}`}>
              <span className="font-bold text-sm sm:text-lg text-foreground whitespace-nowrap">
                {t("hero.title")}
              </span>
              <span className="text-xs text-muted-foreground -mt-1 hidden sm:block">
                Academy
              </span>
            </div>
          </div>

          {/* Desktop Navigation - Center for both languages */}
          <nav className={`hidden lg:flex items-center gap-6 xl:gap-8 order-2`}>
            <a
              href="#home"
              className="text-sm font-medium text-foreground hover:text-primary-600 transition-colors whitespace-nowrap"
            >
              {t("nav.home")}
            </a>
            <a
              href="#plans"
              className="text-sm font-medium text-muted-foreground hover:text-primary-600 transition-colors whitespace-nowrap"
            >
              {t("nav.plans")}
            </a>
            <a
              href="#teachers"
              className="text-sm font-medium text-muted-foreground hover:text-primary-600 transition-colors whitespace-nowrap"
            >
              {t("nav.teachers")}
            </a>
            <a
              href="#about"
              className="text-sm font-medium text-muted-foreground hover:text-primary-600 transition-colors whitespace-nowrap"
            >
              {t("nav.about")}
            </a>
            <a
              href="#contact"
              className="text-sm font-medium text-muted-foreground hover:text-primary-600 transition-colors whitespace-nowrap"
            >
              {t("nav.contact")}
            </a>
          </nav>

          {/* Desktop Actions - Right side for Arabic, Left side for French */}
          <div
            className={`hidden lg:flex items-center gap-3 ${isArabic ? "order-3" : "order-3"}`}
          >
            <LanguageSwitcher />
            <Button
              variant="ghost"
              size="sm"
              className="whitespace-nowrap text-xs sm:text-sm"
            >
              {t("nav.login")}
            </Button>
            <Button
              asChild
              size="sm"
              className="bg-yellow-500 hover:bg-yellow-600 text-yellow-foreground whitespace-nowrap text-xs sm:text-sm"
            >
              <a href="/register">{t("nav.register")}</a>
            </Button>
          </div>

          {/* Mobile Menu Button - Right side for Arabic, Left side for French */}
          <div
            className={`lg:hidden flex items-center gap-2 ${isArabic ? "order-3" : "order-3"}`}
          >
            <div className="scale-90 sm:scale-100">
              <LanguageSwitcher />
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="h-8 w-8 sm:h-10 sm:w-10 p-0"
            >
              {mobileMenuOpen ? (
                <X className="h-4 w-4 sm:h-5 sm:w-5" />
              ) : (
                <Menu className="h-4 w-4 sm:h-5 sm:w-5" />
              )}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-border py-3 sm:py-4">
            <nav className="flex flex-col gap-3 sm:gap-4">
              <a
                href="#home"
                className={`text-sm font-medium text-foreground hover:text-primary-600 transition-colors py-1 ${isArabic ? "text-right" : "text-left"}`}
                onClick={() => setMobileMenuOpen(false)}
              >
                {t("nav.home")}
              </a>
              <a
                href="#plans"
                className={`text-sm font-medium text-muted-foreground hover:text-primary-600 transition-colors py-1 ${isArabic ? "text-right" : "text-left"}`}
                onClick={() => setMobileMenuOpen(false)}
              >
                {t("nav.plans")}
              </a>
              <a
                href="#teachers"
                className={`text-sm font-medium text-muted-foreground hover:text-primary-600 transition-colors py-1 ${isArabic ? "text-right" : "text-left"}`}
                onClick={() => setMobileMenuOpen(false)}
              >
                {t("nav.teachers")}
              </a>
              <a
                href="#about"
                className={`text-sm font-medium text-muted-foreground hover:text-primary-600 transition-colors py-1 ${isArabic ? "text-right" : "text-left"}`}
                onClick={() => setMobileMenuOpen(false)}
              >
                {t("nav.about")}
              </a>
              <a
                href="#contact"
                className={`text-sm font-medium text-muted-foreground hover:text-primary-600 transition-colors py-1 ${isArabic ? "text-right" : "text-left"}`}
                onClick={() => setMobileMenuOpen(false)}
              >
                {t("nav.contact")}
              </a>
              <div
                className={`flex gap-2 pt-3 sm:pt-4 border-t border-border ${isArabic ? "flex-row-reverse" : ""}`}
              >
                <Button
                  variant="ghost"
                  size="sm"
                  className="flex-1 text-xs sm:text-sm"
                >
                  {t("nav.login")}
                </Button>
                <Button
                  asChild
                  size="sm"
                  className="flex-1 bg-yellow-500 hover:bg-yellow-600 text-yellow-foreground text-xs sm:text-sm"
                >
                  <a href="/register">{t("nav.register")}</a>
                </Button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

const HeroSection = () => {
  const { t, language } = useLanguage();
  const isArabic = language === "ar";

  return (
    <section
      id="home"
      className="pt-20 sm:pt-24 lg:pt-28 pb-12 sm:pb-16 bg-gradient-to-br from-primary-50 via-white to-primary-100 overflow-hidden"
    >
      <div className="container mx-auto px-3 sm:px-4 lg:px-6">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          <div className="space-y-6 sm:space-y-8">
            <div className="space-y-4 sm:space-y-6">
              <div
                className={`inline-flex items-center gap-2 bg-yellow-100 text-yellow-800 px-3 sm:px-4 py-2 rounded-full text-xs sm:text-sm font-medium animate-pulse ${isArabic ? "flex-row-reverse" : ""}`}
              >
                <Star className="h-3 w-3 sm:h-4 sm:w-4" />
                <span className="whitespace-nowrap">
                  {isArabic
                    ? "منصة التعليم الأولى في المنطقة"
                    : "Plateforme éducative #1 de la région"}
                </span>
              </div>
              <h1
                className={`text-2xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-foreground leading-tight ${isArabic ? "text-right" : "text-left"}`}
              >
                {t("hero.title")}
              </h1>
              <h2
                className={`text-lg sm:text-xl lg:text-2xl text-primary-600 font-semibold ${isArabic ? "text-right" : "text-left"}`}
              >
                {t("hero.subtitle")}
              </h2>
              <p
                className={`text-base sm:text-lg text-muted-foreground leading-relaxed max-w-full lg:max-w-lg ${isArabic ? "text-right" : "text-left"}`}
              >
                {t("hero.description")}
              </p>
            </div>

            <div
              className={`flex flex-col sm:flex-row gap-3 sm:gap-4 ${isArabic ? "sm:flex-row-reverse" : ""}`}
            >
              <Button
                size="lg"
                className="bg-primary-600 hover:bg-primary-700 text-primary-foreground text-sm sm:text-lg px-6 sm:px-8 py-4 sm:py-6 transform hover:scale-105 transition-all duration-200"
              >
                <PlayCircle
                  className={`h-4 w-4 sm:h-5 sm:w-5 ${isArabic ? "ml-2" : "mr-2"}`}
                />
                {t("hero.cta.primary")}
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="text-sm sm:text-lg px-6 sm:px-8 py-4 sm:py-6 border-primary-200 text-primary-700 hover:bg-primary-50 transform hover:scale-105 transition-all duration-200"
              >
                <BookOpen
                  className={`h-4 w-4 sm:h-5 sm:w-5 ${isArabic ? "ml-2" : "mr-2"}`}
                />
                {t("hero.cta.secondary")}
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 pt-8 border-t border-border">
              <div className="text-center transform hover:scale-105 transition-transform duration-200">
                <div className="text-2xl font-bold text-primary-600">25K+</div>
                <div className="text-sm text-muted-foreground">
                  {t("stats.students")}
                </div>
              </div>
              <div className="text-center transform hover:scale-105 transition-transform duration-200">
                <div className="text-2xl font-bold text-primary-600">180+</div>
                <div className="text-sm text-muted-foreground">
                  {t("stats.courses")}
                </div>
              </div>
              <div className="text-center transform hover:scale-105 transition-transform duration-200">
                <div className="text-2xl font-bold text-primary-600">75+</div>
                <div className="text-sm text-muted-foreground">
                  {t("stats.teachers")}
                </div>
              </div>
              <div className="text-center transform hover:scale-105 transition-transform duration-200">
                <div className="text-2xl font-bold text-yellow-600">98%</div>
                <div className="text-sm text-muted-foreground">
                  {t("stats.success")}
                </div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="relative z-10">
              <img
                src="https://images.pexels.com/photos/6894013/pexels-photo-6894013.jpeg"
                alt="Student learning online"
                className="rounded-2xl shadow-2xl w-full h-auto object-cover"
              />
              <div className="absolute -bottom-6 -left-6 bg-white rounded-2xl shadow-xl p-6 max-w-xs">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center">
                    <BookOpen className="h-6 w-6 text-primary-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">
                      {isArabic
                        ? "الرياضيات المتقدمة"
                        : "Mathématiques Avancées"}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {isArabic ? "د. أحمد محمود" : "Dr. Ahmed Mahmoud"}
                    </p>
                  </div>
                </div>
                <div className="mt-4 h-2 bg-primary-100 rounded-full overflow-hidden">
                  <div className="h-full bg-primary-600 w-3/4 rounded-full"></div>
                </div>
                <div className="flex items-center justify-between text-sm mt-2">
                  <span className="text-muted-foreground">
                    {isArabic ? "التقدم: 75%" : "Progrès: 75%"}
                  </span>
                  <span className="text-yellow-600 font-medium">4.9 ⭐</span>
                </div>
              </div>
            </div>
            {/* Background decorations */}
            <div className="absolute -top-6 -right-6 w-24 h-24 bg-yellow-200 rounded-full opacity-50 animate-bounce"></div>
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-primary-200 rounded-full opacity-50 animate-pulse"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

const FeaturesSection = () => {
  const { t, language } = useLanguage();
  const isArabic = language === "ar";

  const features = [
    {
      icon: Target,
      title: t("features.interactive"),
      description: t("features.interactive.desc"),
      color: "bg-primary-100 text-primary-600",
    },
    {
      icon: Users,
      title: t("features.expert"),
      description: t("features.expert.desc"),
      color: "bg-yellow-100 text-yellow-600",
    },
    {
      icon: Clock,
      title: t("features.support"),
      description: t("features.support.desc"),
      color: "bg-primary-100 text-primary-600",
    },
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">
            {t("features.title")}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {isArabic
              ? "نوفر لك أفضل تجربة تعليمية مع أحدث الأدوات والتقنيات"
              : "Nous vous offrons la meilleure expérience d'apprentissage avec les derniers outils et technologies"}
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card
              key={index}
              className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
            >
              <CardContent className="p-8 text-center space-y-4">
                <div
                  className={`w-16 h-16 ${feature.color} rounded-2xl flex items-center justify-center mx-auto`}
                >
                  <feature.icon className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-semibold text-foreground">
                  {feature.title}
                </h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

const PlansSection = () => {
  const { t, language } = useLanguage();
  const isArabic = language === "ar";

  const plans = [
    {
      name: t("plans.basic"),
      price: isArabic ? "199 ريال" : "199 SAR",
      period: t("plans.month"),
      features: [
        isArabic ? "الوصول إلى 5 مواد" : "Accès à 5 matières",
        isArabic ? "دعم فني أساسي" : "Support technique de base",
        isArabic ? "اختبارات شهرية" : "Tests mensuels",
      ],
      popular: false,
    },
    {
      name: t("plans.premium"),
      price: isArabic ? "399 ريال" : "399 SAR",
      period: t("plans.month"),
      features: [
        isArabic ? "الوصول إلى جميع المواد" : "Accès à toutes les matières",
        isArabic ? "دعم مباشر 24/7" : "Support direct 24/7",
        isArabic ? "اختبارات أسبوعية" : "Tests hebdomadaires",
        isArabic ? "جلسات مراجعة مباشرة" : "Sessions de révision en direct",
      ],
      popular: true,
    },
    {
      name: t("plans.pro"),
      price: isArabic ? "599 ريال" : "599 SAR",
      period: t("plans.month"),
      features: [
        isArabic
          ? "كل مميزات الخطة المتميزة"
          : "Toutes les fonctionnalités Premium",
        isArabic ? "متابعة شخصية" : "Suivi personnalisé",
        isArabic ? "اختبارات تجريبية" : "Tests d'évaluation",
        isArabic ? "ضمان النجاح" : "Garantie de succès",
      ],
      popular: false,
    },
  ];

  return (
    <section
      id="plans"
      className="py-20 bg-gradient-to-br from-primary-50 to-white"
    >
      <div className="container mx-auto px-4">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">
            {t("plans.title")}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {isArabic
              ? "خطط مرنة تناسب جميع احتياجاتك التعليمية"
              : "Plans flexibles qui répondent à tous vos besoins éducatifs"}
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <Card
              key={index}
              className={`relative border-2 transition-all duration-300 transform hover:-translate-y-2 ${
                plan.popular
                  ? "border-yellow-500 shadow-2xl scale-105"
                  : "border-border shadow-lg hover:shadow-xl"
              }`}
            >
              {plan.popular && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-yellow-500 text-yellow-foreground">
                  {t("plans.popular")}
                </Badge>
              )}
              <CardContent className="p-8 text-center space-y-6">
                <div>
                  <h3 className="text-xl font-semibold text-foreground mb-2">
                    {plan.name}
                  </h3>
                  <div className="text-3xl font-bold text-primary-600">
                    {plan.price}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {plan.period}
                  </div>
                </div>
                <ul className="space-y-3">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center gap-3">
                      <CheckCircle className="h-5 w-5 text-primary-600 flex-shrink-0" />
                      <span className="text-sm text-muted-foreground">
                        {feature}
                      </span>
                    </li>
                  ))}
                </ul>
                <Button
                  className={`w-full ${
                    plan.popular
                      ? "bg-yellow-500 hover:bg-yellow-600 text-yellow-foreground"
                      : "bg-primary-600 hover:bg-primary-700"
                  }`}
                >
                  {t("plans.choose")}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

const TeachersSection = () => {
  const { t, language } = useLanguage();
  const isArabic = language === "ar";

  const teachers = [
    {
      name: isArabic ? "د. أحمد محمود" : "Dr. Ahmed Mahmoud",
      subject: isArabic ? "الرياضيات" : "Mathématiques",
      experience: "12",
      students: "2500+",
      rating: "4.9",
      image:
        "https://images.pexels.com/photos/5905923/pexels-photo-5905923.jpeg",
    },
    {
      name: isArabic ? "د. فاطمة علي" : "Dr. Fatima Ali",
      subject: isArabic ? "الفيزياء" : "Physique",
      experience: "8",
      students: "1800+",
      rating: "4.8",
      image:
        "https://images.pexels.com/photos/5212345/pexels-photo-5212345.jpeg",
    },
    {
      name: isArabic ? "د. محمد حسن" : "Dr. Mohamed Hassan",
      subject: isArabic ? "الكيمياء" : "Chimie",
      experience: "10",
      students: "2100+",
      rating: "4.9",
      image:
        "https://images.pexels.com/photos/5905923/pexels-photo-5905923.jpeg",
    },
  ];

  return (
    <section id="teachers" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">
            {t("teachers.title")}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {t("teachers.subtitle")}
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {teachers.map((teacher, index) => (
            <Card
              key={index}
              className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 overflow-hidden"
            >
              <div className="relative h-48 bg-gradient-to-br from-primary-100 to-primary-200">
                <img
                  src={teacher.image}
                  alt={teacher.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 right-4 bg-yellow-500 text-yellow-foreground px-2 py-1 rounded-full text-xs font-medium">
                  ⭐ {teacher.rating}
                </div>
              </div>
              <CardContent className="p-6 space-y-4">
                <div className="text-center">
                  <h3 className="text-xl font-semibold text-foreground">
                    {teacher.name}
                  </h3>
                  <p className="text-primary-600 font-medium">
                    {teacher.subject}
                  </p>
                </div>
                <div className="grid grid-cols-3 gap-4 text-center text-sm">
                  <div>
                    <div className="font-semibold text-foreground">
                      {teacher.experience}
                    </div>
                    <div className="text-muted-foreground">
                      {t("teachers.experience")}
                    </div>
                  </div>
                  <div>
                    <div className="font-semibold text-foreground">
                      {teacher.students}
                    </div>
                    <div className="text-muted-foreground">
                      {t("teachers.students")}
                    </div>
                  </div>
                  <div>
                    <div className="font-semibold text-foreground">
                      {teacher.rating}/5
                    </div>
                    <div className="text-muted-foreground">
                      {t("teachers.rating")}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

const ReviewsSection = () => {
  const { t, language } = useLanguage();
  const isArabic = language === "ar";

  const reviews = [
    {
      name: isArabic ? "سارة أحمد" : "Sarah Ahmed",
      grade: isArabic ? "الصف الثالث الثانوي" : "Terminale",
      review: isArabic
        ? "أكاديمية نجاح غيرت حياتي الدراسية! المدرسون رائعون والشرح واضح جداً. حصلت على 98% في الثانوية العامة بفضلهم."
        : "Najah Academy a changé ma vie scolaire ! Les enseignants sont fantastiques et les explications très claires. J'ai obtenu 98% au baccalauréat grâce à eux.",
      rating: 5,
      image:
        "https://images.pexels.com/photos/6682475/pexels-photo-6682475.jpeg",
    },
    {
      name: isArabic ? "محمد خالد" : "Mohamed Khaled",
      grade: isArabic ? "الصف الثاني الثانوي" : "Première",
      review: isArabic
        ? "المنصة سهلة الاستخدام والدروس ممتعة وتفاعلية. أنصح بها كل طالب يريد التفوق في دراسته."
        : "La plateforme est facile à utiliser et les cours sont amusants et interactifs. Je la recommande à tout étudiant qui veut exceller dans ses études.",
      rating: 5,
      image:
        "https://images.pexels.com/photos/32752097/pexels-photo-32752097.jpeg",
    },
    {
      name: isArabic ? "نور محمد" : "Nour Mohamed",
      grade: isArabic ? "الصف الأول الثانوي" : "Seconde",
      review: isArabic
        ? "بدأت مع أكاديمية نجاح من بداية الثانوية وأشعر بالثقة في قدراتي. الدعم المستمر من المدرسين لا يُقدر بثمن."
        : "J'ai commencé avec Najah Academy dès le début du lycée et je me sens confiante dans mes capacités. Le soutien continu des enseignants est inestimable.",
      rating: 5,
      image:
        "https://images.pexels.com/photos/6682475/pexels-photo-6682475.jpeg",
    },
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-primary-50 to-white">
      <div className="container mx-auto px-4">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">
            {t("reviews.title")}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {t("reviews.subtitle")}
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <Card
              key={index}
              className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
            >
              <CardContent className="p-6 space-y-4">
                <div className="flex gap-1 mb-4">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star
                      key={i}
                      className="h-4 w-4 fill-yellow-500 text-yellow-500"
                    />
                  ))}
                </div>
                <p className="text-muted-foreground leading-relaxed">
                  "{review.review}"
                </p>
                <div className="flex items-center gap-3 pt-4 border-t border-border">
                  <img
                    src={review.image}
                    alt={review.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div>
                    <div className="font-semibold text-foreground">
                      {review.name}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {review.grade}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

const TipsSection = () => {
  const { t, language } = useLanguage();
  const isArabic = language === "ar";

  const tips = [
    {
      icon: Brain,
      title: isArabic ? "التركيز والانتباه" : "Concentration et attention",
      description: isArabic
        ? "خصص وقتاً محدداً للدراسة بدون أي مشتتات خارجية"
        : "Consacrez un temps déterminé à l'étude sans distractions extérieures",
    },
    {
      icon: Calendar,
      title: isArabic ? "التنظيم والتخطيط" : "Organisation et planification",
      description: isArabic
        ? "ضع جدولاً زمنياً واضحاً واتبعه بانتظام"
        : "Établissez un emploi du temps clair et suivez-le régulièrement",
    },
    {
      icon: Lightbulb,
      title: isArabic ? "التعلم التفاعلي" : "Apprentissage interactif",
      description: isArabic
        ? "استخدم طرق التعلم المختلفة لتثبيت المعلومات"
        : "Utilisez différentes méthodes d'apprentissage pour fixer les informations",
    },
    {
      icon: TrendingUp,
      title: isArabic ? "المراجعة المستمرة" : "Révision continue",
      description: isArabic
        ? "راجع ما تعلمته بانتظام لضمان عدم النسيان"
        : "Révisez régulièrement ce que vous avez appris pour éviter l'oubli",
    },
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">
            {t("tips.title")}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {t("tips.subtitle")}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {tips.map((tip, index) => (
            <Card
              key={index}
              className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 text-center"
            >
              <CardContent className="p-6 space-y-4">
                <div className="w-16 h-16 bg-primary-100 text-primary-600 rounded-2xl flex items-center justify-center mx-auto">
                  <tip.icon className="h-8 w-8" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">
                  {tip.title}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {tip.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

const AboutSection = () => {
  const { t, language } = useLanguage();
  const isArabic = language === "ar";

  return (
    <section
      id="about"
      className="py-20 bg-gradient-to-br from-primary-50 to-white"
    >
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">
              {t("about.title")}
            </h2>
            <h3 className="text-xl text-primary-600 font-semibold">
              {t("about.subtitle")}
            </h3>
            <p className="text-lg text-muted-foreground leading-relaxed">
              {t("about.description")}
            </p>
            <div className="grid grid-cols-2 gap-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-primary-100 text-primary-600 rounded-xl flex items-center justify-center">
                  <Shield className="h-6 w-6" />
                </div>
                <div>
                  <div className="font-semibold text-foreground">
                    {isArabic ? "جودة مضمونة" : "Qualité garantie"}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {isArabic ? "محتوى معتمد" : "Contenu certifié"}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-yellow-100 text-yellow-600 rounded-xl flex items-center justify-center">
                  <HeartHandshake className="h-6 w-6" />
                </div>
                <div>
                  <div className="font-semibold text-foreground">
                    {isArabic ? "دعم شخصي" : "Support personnel"}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {isArabic ? "متابعة مستمرة" : "Suivi continu"}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="relative">
            <img
              src="https://images.pexels.com/photos/5212345/pexels-photo-5212345.jpeg"
              alt="About Najah Academy"
              className="rounded-2xl shadow-2xl w-full h-auto object-cover"
            />
            <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-yellow-200 rounded-full opacity-50 animate-pulse"></div>
            <div className="absolute -top-6 -left-6 w-32 h-32 bg-primary-200 rounded-full opacity-50 animate-bounce"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

const ContactSection = () => {
  const { t, language } = useLanguage();
  const isArabic = language === "ar";

  return (
    <section id="contact" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">
            {t("contact.title")}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {t("contact.subtitle")}
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          <Card className="border-0 shadow-lg">
            <CardContent className="p-8">
              <form className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    {t("contact.name")}
                  </label>
                  <Input placeholder={t("contact.name")} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    {t("contact.email")}
                  </label>
                  <Input type="email" placeholder={t("contact.email")} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    {t("contact.message")}
                  </label>
                  <Textarea placeholder={t("contact.message")} rows={5} />
                </div>
                <Button className="w-full bg-primary-600 hover:bg-primary-700">
                  <MessageCircle className="h-4 w-4 mr-2" />
                  {t("contact.send")}
                </Button>
              </form>
            </CardContent>
          </Card>

          <div className="space-y-8">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-primary-100 text-primary-600 rounded-xl flex items-center justify-center">
                <Phone className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-1">
                  {isArabic ? "الهاتف" : "Téléphone"}
                </h3>
                <p className="text-muted-foreground">+966 50 123 4567</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-yellow-100 text-yellow-600 rounded-xl flex items-center justify-center">
                <Mail className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-1">
                  {isArabic ? "البريد الإلكتروني" : "Email"}
                </h3>
                <p className="text-muted-foreground">info@najahacademy.com</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-primary-100 text-primary-600 rounded-xl flex items-center justify-center">
                <MapPin className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-1">
                  {isArabic ? "العنوان" : "Adresse"}
                </h3>
                <p className="text-muted-foreground">
                  {isArabic
                    ? "الرياض، المملكة العربية السعودية"
                    : "Riyadh, Arabie Saoudite"}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  const { t, language } = useLanguage();
  const isArabic = language === "ar";

  return (
    <footer className="bg-primary-900 text-white py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-yellow-500 rounded-xl flex items-center justify-center">
                <GraduationCap className="h-6 w-6 text-white" />
              </div>
              <span className="font-bold text-lg">{t("hero.title")}</span>
            </div>
            <p className="text-primary-200">
              {isArabic
                ? "منصة التعليم الإلكتروني الرائدة للثانوية ��لعامة"
                : "Plateforme d'apprentissage en ligne de premier plan pour le lycée"}
            </p>
            <div className="flex gap-4">
              <div className="w-8 h-8 bg-primary-700 rounded-lg flex items-center justify-center cursor-pointer hover:bg-primary-600 transition-colors">
                📱
              </div>
              <div className="w-8 h-8 bg-primary-700 rounded-lg flex items-center justify-center cursor-pointer hover:bg-primary-600 transition-colors">
                📧
              </div>
              <div className="w-8 h-8 bg-primary-700 rounded-lg flex items-center justify-center cursor-pointer hover:bg-primary-600 transition-colors">
                🌐
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="font-semibold text-lg">
              {isArabic ? "روابط سريعة" : "Liens rapides"}
            </h4>
            <div className="space-y-2">
              <a
                href="#home"
                className="block text-primary-200 hover:text-white transition-colors"
              >
                {t("nav.home")}
              </a>
              <a
                href="#plans"
                className="block text-primary-200 hover:text-white transition-colors"
              >
                {t("nav.plans")}
              </a>
              <a
                href="#teachers"
                className="block text-primary-200 hover:text-white transition-colors"
              >
                {t("nav.teachers")}
              </a>
              <a
                href="#about"
                className="block text-primary-200 hover:text-white transition-colors"
              >
                {t("nav.about")}
              </a>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="font-semibold text-lg">
              {isArabic ? "الدعم" : "Support"}
            </h4>
            <div className="space-y-2">
              <a
                href="#"
                className="block text-primary-200 hover:text-white transition-colors"
              >
                {isArabic ? "مركز المساعدة" : "Centre d'aide"}
              </a>
              <a
                href="#contact"
                className="block text-primary-200 hover:text-white transition-colors"
              >
                {t("nav.contact")}
              </a>
              <a
                href="#"
                className="block text-primary-200 hover:text-white transition-colors"
              >
                {isArabic ? "الأسئلة الشائعة" : "FAQ"}
              </a>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="font-semibold text-lg">
              {isArabic ? "تواصل معنا" : "Contactez-nous"}
            </h4>
            <div className="space-y-2 text-primary-200">
              <p>info@najahacademy.com</p>
              <p>+966 50 123 4567</p>
              <p>
                {isArabic
                  ? "الرياض، المملكة العربية السعودية"
                  : "Riyadh, Arabie Saoudite"}
              </p>
            </div>
          </div>
        </div>

        <div className="border-t border-primary-800 mt-12 pt-8 text-center text-primary-300">
          <p>
            © 2024 {t("hero.title")}.{" "}
            {isArabic ? "جميع الحقوق محفوظة." : "Tous droits réservés."}
          </p>
        </div>
      </div>
    </footer>
  );
};

export default function Index() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <HeroSection />
      <FeaturesSection />
      <PlansSection />
      <TeachersSection />
      <ReviewsSection />
      <TipsSection />
      <AboutSection />
      <ContactSection />
      <Footer />
    </div>
  );
}
