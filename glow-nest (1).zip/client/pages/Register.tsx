import { useLanguage } from "@/contexts/LanguageContext";
import { LanguageSwitcher } from "@/components/ui/language-switcher";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  GraduationCap,
  ArrowRight,
  ArrowLeft,
  CheckCircle,
} from "lucide-react";
import { useState } from "react";

export default function Register() {
  const { t, language } = useLanguage();
  const isArabic = language === "ar";
  const [step, setStep] = useState(1);

  const benefits = [
    isArabic ? "الوصول إلى جميع الدورات" : "Accès à tous les cours",
    isArabic ? "دعم فني مجاني" : "Support technique gratuit",
    isArabic ? "شهادات معتمدة" : "Certificats accrédités",
    isArabic ? "مجتمع تعليمي تفاعلي" : "Communauté d'apprentissage interactive",
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-white to-primary-100">
      {/* Header */}
      <header className="border-b border-border bg-white/95 backdrop-blur-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <a href="/" className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary-500 to-primary-700 rounded-xl flex items-center justify-center">
                <GraduationCap className="h-6 w-6 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-lg text-foreground">
                  {t("hero.title")}
                </span>
                <span className="text-xs text-muted-foreground -mt-1">
                  Academy
                </span>
              </div>
            </a>
            <LanguageSwitcher />
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            {/* Left Side - Benefits */}
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-3xl md:text-4xl font-bold text-foreground">
                  {isArabic
                    ? "انضم إلى أكاديمية نجاح"
                    : "Rejoignez Najah Academy"}
                </h1>
                <p className="text-lg text-muted-foreground">
                  {isArabic
                    ? "ابدأ رحلتك التعليمية اليوم واحصل على أفضل النتائج"
                    : "Commencez votre parcours éducatif aujourd'hui et obtenez les meilleurs résultats"}
                </p>
              </div>

              <div className="space-y-4">
                <h3 className="text-xl font-semibold text-foreground">
                  {isArabic ? "ما ستحصل عليه:" : "Ce que vous obtiendrez :"}
                </h3>
                <div className="space-y-3">
                  {benefits.map((benefit, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <CheckCircle className="h-5 w-5 text-primary-600 flex-shrink-0" />
                      <span className="text-muted-foreground">{benefit}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-yellow-600 mb-2">
                    {isArabic ? "عرض خاص!" : "Offre spéciale !"}
                  </div>
                  <p className="text-sm text-yellow-800">
                    {isArabic
                      ? "احصل على خصم 50% على الشهر الأول عند التسجيل اليوم"
                      : "Obtenez 50% de réduction sur le premier mois en vous inscrivant aujourd'hui"}
                  </p>
                </div>
              </div>
            </div>

            {/* Right Side - Registration Form */}
            <Card className="border-0 shadow-2xl">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl font-bold">
                  {isArabic ? "إنشاء حساب جديد" : "Créer un nouveau compte"}
                </CardTitle>
                <p className="text-muted-foreground">
                  {isArabic
                    ? "املأ البيانات أدناه للبدء"
                    : "Remplissez les informations ci-dessous pour commencer"}
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                {step === 1 && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="firstName">
                          {isArabic ? "الاسم الأول" : "Prénom"}
                        </Label>
                        <Input
                          id="firstName"
                          placeholder={isArabic ? "أحمد" : "Ahmed"}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lastName">
                          {isArabic ? "اسم العائلة" : "Nom de famille"}
                        </Label>
                        <Input
                          id="lastName"
                          placeholder={isArabic ? "محمد" : "Mohamed"}
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">
                        {isArabic ? "البريد الإلكتروني" : "Email"}
                      </Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="ahmed@example.com"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">
                        {isArabic ? "رقم الهاتف" : "Numéro de téléphone"}
                      </Label>
                      <Input id="phone" placeholder="+966 50 123 4567" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="grade">
                        {isArabic ? "الصف الدراسي" : "Niveau scolaire"}
                      </Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue
                            placeholder={
                              isArabic ? "اختر الصف" : "Choisir le niveau"
                            }
                          />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="grade1">
                            {isArabic ? "الصف الأول الثانوي" : "Seconde"}
                          </SelectItem>
                          <SelectItem value="grade2">
                            {isArabic ? "الصف الثاني الثانوي" : "Première"}
                          </SelectItem>
                          <SelectItem value="grade3">
                            {isArabic ? "الصف الثالث الثانوي" : "Terminale"}
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <Button
                      onClick={() => setStep(2)}
                      className="w-full bg-primary-600 hover:bg-primary-700"
                      size="lg"
                    >
                      {isArabic ? "التالي" : "Suivant"}
                      {isArabic ? (
                        <ArrowLeft className="h-4 w-4 ml-2" />
                      ) : (
                        <ArrowRight className="h-4 w-4 ml-2" />
                      )}
                    </Button>
                  </div>
                )}

                {step === 2 && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="password">
                        {isArabic ? "كلمة المرور" : "Mot de passe"}
                      </Label>
                      <Input id="password" type="password" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword">
                        {isArabic
                          ? "تأكيد كلمة المرور"
                          : "Confirmer le mot de passe"}
                      </Label>
                      <Input id="confirmPassword" type="password" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="plan">
                        {isArabic ? "اختر الخطة" : "Choisir le plan"}
                      </Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue
                            placeholder={
                              isArabic
                                ? "اختر خطة الاشتراك"
                                : "Choisir un plan d'abonnement"
                            }
                          />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="basic">
                            {isArabic
                              ? "الخطة الأساسية - 199 ريال/شهر"
                              : "Plan de base - 199 SAR/mois"}
                          </SelectItem>
                          <SelectItem value="premium">
                            {isArabic
                              ? "الخطة المتميزة - 399 ريال/شهر"
                              : "Plan Premium - 399 SAR/mois"}
                          </SelectItem>
                          <SelectItem value="pro">
                            {isArabic
                              ? "الخطة الاحترافية - 599 ريال/شهر"
                              : "Plan Professionnel - 599 SAR/mois"}
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Checkbox id="terms" />
                      <Label htmlFor="terms" className="text-sm">
                        {isArabic
                          ? "أوافق على الشروط والأحكام وسياسة الخصوصية"
                          : "J'accepte les termes et conditions et la politique de confidentialité"}
                      </Label>
                    </div>
                    <div className="space-y-3">
                      <Button
                        className="w-full bg-yellow-500 hover:bg-yellow-600 text-yellow-foreground"
                        size="lg"
                      >
                        {isArabic ? "إنشاء الحساب" : "Créer le compte"}
                        <GraduationCap className="h-4 w-4 ml-2" />
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => setStep(1)}
                        className="w-full"
                        size="lg"
                      >
                        {isArabic ? "السابق" : "Précédent"}
                        {isArabic ? (
                          <ArrowRight className="h-4 w-4 ml-2" />
                        ) : (
                          <ArrowLeft className="h-4 w-4 ml-2" />
                        )}
                      </Button>
                    </div>
                  </div>
                )}

                <div className="text-center pt-4 border-t border-border">
                  <p className="text-sm text-muted-foreground">
                    {isArabic
                      ? "لديك حساب بالفعل؟"
                      : "Vous avez déjà un compte ?"}{" "}
                    <a
                      href="#"
                      className="text-primary-600 hover:underline font-medium"
                    >
                      {isArabic ? "تسجيل الدخول" : "Se connecter"}
                    </a>
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
